#include <iostream>
#include "run_system_command_library.h"
using namespace foretify;

void run_system_command_t::run_system_command(string_t command_in){
    printf("system runner executed.\n");
    system(command_in);
}